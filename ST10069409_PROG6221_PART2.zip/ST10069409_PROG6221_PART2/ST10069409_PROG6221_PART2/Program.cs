﻿using System;

namespace ST10069409_PROG6221_PART2
{

    class program
    {
        static void Main(string[] args)
        {

            //object to call recipe manage method
            RecipeManager recipeManager = new RecipeManager();
            bool running = true;


            //user prompt to choose what they want to do
            while (running)
            {
                Console.Clear();
                Console.WriteLine("Welcome!");
                Console.WriteLine("Select an option:");
                Console.WriteLine("1. Add a recipe");
                Console.WriteLine("2. Display recipes");
                Console.WriteLine("3. Scale recipe");
                Console.WriteLine("4. Reset the quantity recipe");
                Console.WriteLine("5. Delete all recipes");
                Console.WriteLine("6. Exit");

                int choice = GetIntInput("Enter your choice (1-6): ");


                //switch statement to call methods needed in the cases below
                switch (choice)
                {
                    case 1:
                        recipeManager.AddRecipe();
                        break;
                    case 2:
                        recipeManager.DisplayRecipes();
                        break;
                    case 3:
                        recipeManager.ScaleRecipe();
                        break;
                    case 4:
                        recipeManager.ResetRecipe();
                        break;
                    case 5:
                        recipeManager.ClearRecipes();
                        break;
                    case 6:
                        running = false;
                        Console.WriteLine("Goodbye!");
                        break;
                    default:
                        Console.WriteLine("Invalid choice. Please try again.");
                        break;
                }

                Console.WriteLine("Press Enter to continue...");
                Console.ReadLine();
            }
        }

        //This line declares a static method named GetIntInput that takes a string parameter named prompt.
        //This parameter is intended to be a prompt message displayed to the user to instruct them on what type of input is expected.
        static int GetIntInput(string prompt)
        {
            int input;
            while (!int.TryParse(Console.ReadLine(), out input))
            {
                Console.WriteLine("Invalid input. Please enter a number.");
            }
            return input;
        }
    }


   
    class RecipeManager
    {
        private List<Recipe> recipes;


        // This line initializes a new List object named recipes
        public RecipeManager()
        {
            recipes = new List<Recipe>();
        }

        //method to add your recipe 
        public void AddRecipe()
        {
            //prompt user input
            Console.WriteLine("Enter Recipe name:");
            string name = Console.ReadLine();

            Console.WriteLine("Enter the number of ingredients:");
            int numIngredients = Convert.ToInt32(Console.ReadLine());
            List<Ingredient> ingredients = new List<Ingredient>();

            for (int i = 0; i < numIngredients; i++)
            {
                Console.WriteLine($"Enter details for ingredient {i + 1}:");
                Console.WriteLine("Enter ingredient name:");
                string ingredientName = Console.ReadLine();
                Console.WriteLine("Enter quantity:");
                double quantity = Convert.ToDouble(Console.ReadLine());
                Console.WriteLine("Enter unit of measurement:");
                string unit = Console.ReadLine();
                Console.WriteLine("Enter calories:");
                int calories = Convert.ToInt32(Console.ReadLine());

                //prompts users to choose a food group
                Console.WriteLine("Selecta food group ingredient belongs in:");
                Console.WriteLine("1. Carbohydrates ");
                Console.WriteLine("2. Protein");
                Console.WriteLine("3. Dairy products");
                Console.WriteLine("4. Fruit and vegetables");
                Console.WriteLine("5. Fats and sugars");
                int foodGroupChoice = Convert.ToInt32(Console.ReadLine());
                string foodGroup;

                switch (foodGroupChoice)
                {
                    case 1:
                        foodGroup = "Carbohydrates";
                        break;
                    case 2:
                        foodGroup = "Protein";
                        break;
                    case 3:
                        foodGroup = "Dairy products";
                        break;
                    case 4:
                        foodGroup = "Fruit and vegetables";
                        break;
                    case 5:
                        foodGroup = "Fats and sugars";
                        break;
                    default:
                        foodGroup = "Other";
                        break;
                }

                ingredients.Add(new Ingredient(ingredientName, quantity, unit, calories, foodGroup));
            }

            //prompts user to enter number of steps

            Console.WriteLine("Enter the number of steps:");
            int numSteps = Convert.ToInt32(Console.ReadLine());
            List<string> steps = new List<string>();


            //this line prints a prompt to the console asking the user to enter a step. The {i + 1} part is used to display the step number,
            //starting from 1 instead of 0 (since humans usually start counting from 1).
            for (int i = 0; i < numSteps; i++)
            {
                Console.WriteLine($"Enter step {i + 1}:");
                steps.Add(Console.ReadLine());
            }

            recipes.Add(new Recipe(name, ingredients, steps));
            Console.WriteLine("Recipe Added");
        }


        //method that displays the recipe
        public void DisplayRecipes()
        {
            if (recipes.Count == 0 )
            {
                Console.WriteLine("Recipes Unavailable.");
                return;
            }
           

            Console.WriteLine("Enter the number of the recipe you want to display:");
            recipes.Sort((a, b) => a.Name.CompareTo(b.Name));

            int i = 0;
            foreach (var recipe in recipes)
            {
                i++;
                Console.WriteLine($"{i}. {recipe.Name}");
            }

            int selectedIndex = GetIntInput("Enter the index of the recipe you want to view (1-{recipes.Count}): ") - 1;

            if (selectedIndex < 0 || selectedIndex >= recipes.Count)
            {
                Console.WriteLine("Invalid recipe index.");
                return;
            }

            Recipe selectedRecipe = recipes[selectedIndex];
            DisplayRecipe(selectedRecipe);
        }

        private string GetFoodGroup()
        {
            Console.WriteLine("Choose which food group does the ingriend belong to:");
            Console.WriteLine("1. Carbohydrates");
            Console.WriteLine("2. Protein");
            Console.WriteLine("3. Dairy products");
            Console.WriteLine("4. Fruit and vegetables");
            Console.WriteLine("5. Fats and sugars");

            int choice = GetIntInput("Enter the number corresponding to the food group (1-5): ");
            string foodGroup;

            switch (choice)
            {
                case 1:
                    foodGroup = "Carbohydrates";
                    break;
                case 2:
                    foodGroup = "Protein";
                    break;
                case 3:
                    foodGroup = "Dairy products";
                    break;
                case 4:
                    foodGroup = "Fruit and vegetables";
                    break;
                case 5:
                    foodGroup = "Fats and sugars";
                    break;
                default:
                    Console.WriteLine("Invalid choice, Try again.");
                    foodGroup = "Other";
                    break;
            }

            return foodGroup;
        }


        public void ScaleRecipe()
        {
            if (recipes.Count == 0)
            {
                Console.WriteLine("Recipes Unavailable.");
                return;
            }

            Console.WriteLine("All Recipes:");
            recipes.Sort((a, b) => a.Name.CompareTo(b.Name));

            for (int i = 0; i < recipes.Count; i++)
            {
                Console.WriteLine($"{i + 1}. {recipes[i].Name}");
            }

            int selectedIndex = GetIntInput("Enter the index of the recipe you want to scale (1-{recipes.Count}): ") - 1;

            if (selectedIndex < 0 || selectedIndex >= recipes.Count)
            {
                Console.WriteLine("Invalid recipe index.");
                return;
            }

            Recipe selectedRecipe = recipes[selectedIndex];
            double scaleFactor = GetScaleFactor();
            selectedRecipe.ScaleRecipe(scaleFactor);
            Console.WriteLine("Recipe scaled!");
            DisplayRecipe(selectedRecipe);
        }

        public void ResetRecipe()
        {
            if (recipes.Count == 0)
            {
                Console.WriteLine("Recipes Unavailable.");
                return;
            }

            Console.WriteLine("All Recipes:");
            recipes.Sort((a, b) => a.Name.CompareTo(b.Name));

            for (int i = 0; i < recipes.Count; i++)
            {
                Console.WriteLine($"{i + 1}. {recipes[i].Name}");
            }

            int selectedIndex = GetIntInput("Enter the index of the recipe you want to reset (1-{recipes.Count}): ") - 1;

            if (selectedIndex < 0 || selectedIndex >= recipes.Count)
            {
                Console.WriteLine("Invalid recipe index.");
                return;
            }

            Recipe selectedRecipe = recipes[selectedIndex];
            selectedRecipe.ResetRecipe();
            Console.WriteLine("Recipe reset!");
            DisplayRecipe(selectedRecipe);
        }

        //method clear recipe
        public void ClearRecipes()
        {
            recipes.Clear();
            Console.WriteLine("All recipes have been cleared.");
        }


        //method to display recipe
        private void DisplayRecipe(Recipe recipe)
        {
            Console.WriteLine("Recipe:");

            Console.WriteLine("***********************");
            Console.WriteLine($"Recipe: {recipe.Name}");
            Console.WriteLine("**********************");
            Console.WriteLine("Ingredients:");

            //This loop iterates over each ingredient in the Ingredients collection of a recipe object and prints out information about each ingredient.
            foreach (var ingredient in recipe.Ingredients)
            {
                Console.WriteLine($"- {ingredient.Quantity} {ingredient.Unit} of {ingredient.Name} ({ingredient.Calories} calories, {ingredient.FoodGroup})");
            }
            Console.WriteLine("Steps:");
            for (int i = 0; i < recipe.Steps.Count; i++)
            {
                Console.WriteLine($"{i + 1}. {recipe.Steps[i]}");
            }
            Console.WriteLine("**********************");
            Console.WriteLine($"Total Calories: {recipe.TotalCalories}");
            Console.WriteLine("**********************");
            if (recipe.TotalCalories > 300)
            {
                Console.WriteLine("Warning! calaories are above 300");
            }
        }

        //prompts user to enter a number they wish to scale recipe with, return the new value change
        private double GetScaleFactor()
        {
            Console.WriteLine("Enter the scale factor (0.5, 2, or 3):");
            double scaleFactor;
            while (!double.TryParse(Console.ReadLine(), out scaleFactor) || (scaleFactor != 0.5 && scaleFactor != 2 && scaleFactor != 3))
            {
                Console.WriteLine("Invalid scale factor. Please enter 0.5, 2, or 3.");
            }
            return scaleFactor;
        }

        //This method, GetValidString, is a C# function designed to retrieve a non-empty string input from the user via the console.
        private string GetValidString(string prompt)
        {
            string input;
            do
            {
                Console.Write($"{prompt}: ");
                input = Console.ReadLine().Trim();
            } while (string.IsNullOrWhiteSpace(input));
            return input;
        }


        //This line declares a private method named GetIntInput that takes a string parameter named prompt.
        //This parameter is intended to be a prompt message displayed to the user to instruct them on what type of input is expected.
        private int GetIntInput(string prompt)
        {
            int input;
            while (!int.TryParse(Console.ReadLine(), out input))
            {
                Console.WriteLine("Invalid input. Please enter a number.");
            }
            return input;
        }

        //his line declares a private method named GetDoubleInput that takes a string parameter named prompt.
        //This parameter is used to prompt the user with a message indicating what type of input is expected.
        private double GetDoubleInput(string prompt)
        {
            double input;
            while (!double.TryParse(Console.ReadLine(), out input))
            {
                Console.WriteLine("Invalid input. Please enter a number.");
            }
            return input;
        }
    }

    class Recipe
    {
        public string Name { get; set; }
        public List<Ingredient> Ingredients { get; set; }
        public List<string> Steps { get; set; }
        public double OriginalTotalCalories { get; private set; }
        public double TotalCalories { get; private set; }

        public Recipe(string name, List<Ingredient> ingredients, List<string> steps)
        {
            Name = name;
            Ingredients = ingredients;
            Steps = steps;
            CalculateTotalCalories();
            OriginalTotalCalories = TotalCalories;
        }

        public void ScaleRecipe(double scaleFactor)
        {
            foreach (var ingredient in Ingredients)
            {
                ingredient.Quantity *= scaleFactor;
            }
            CalculateTotalCalories();
        }


        // This line declares a private method named GetDoubleInput. It takes a string parameter named prompt,
        // which is intended to display a message to the user, indicating the type of input expected (presumably a double).
        public void ResetRecipe()
        {
            foreach (var ingredient in Ingredients)
            {
                ingredient.Quantity = ingredient.OriginalQuantity;
            }
            CalculateTotalCalories();
        }

        //calculates the sum of all the calories each ingredient has
        private void CalculateTotalCalories()
        {
            TotalCalories = Ingredients.Sum(i => i.Calories);
        }
    }

    class Ingredient
    {

       
        public string Name { get; set; } // Ingredient name
        public double Quantity { get; set; }  // Ingredient quantity
        public double OriginalQuantity { get; } //original quantity
        public string Unit { get; set; } // Unit of measurement
        public int Calories { get; set; } //Ingredient calories
        public string FoodGroup { get; set; } //Ingredient food group

        //intialzie
        public Ingredient(string name, double quantity, string unit, int calories, string foodGroup)
        {
            Name = name;
            Quantity = quantity;
            OriginalQuantity = quantity;
            Unit = unit;
            Calories = calories;
            FoodGroup = foodGroup;
        }
    }

}